﻿Public Interface IBoardItem
    Property Rank As Integer
    Property File As Char
    Property ItemType As ChessBoardItem
End Interface
