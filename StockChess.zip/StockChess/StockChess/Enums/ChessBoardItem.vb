﻿Public Enum ChessBoardItem
    Piece
    Square
End Enum
