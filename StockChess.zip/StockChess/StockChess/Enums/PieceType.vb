﻿Public Enum PieceType
    King
    Queen
    Bishop
    Knight
    Rook
    Pawn
End Enum
