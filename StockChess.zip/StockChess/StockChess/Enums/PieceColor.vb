﻿Public Enum PieceColor
    White
    Black
End Enum

